'use strict';

module.exports = {

 /* Find the average of three integers */
 computeAverage: (num1, num2, num3) => {
   let average = (num1 + num2 + num3)/3;
   
   return average;
 },
 
 /* Find the factorial of an integer */
 computeFactorial: function(num) {
  if (num ===1 || num ===2 || num === 0)
  {
    return num;
  }
  else 
   {
      return num * this.computeFactorial(num - 1);
   }
 },

 /* Convert a given Celcius temperature to Fahrenheit */
 convertTempCtoF: (cTemp) => {
   let fTemp;
   // your logic goes here
   fTemp =((9/5) * cTemp) + 32; 
   return fTemp;
 },

 /* Convert a given Fahrenheit temperature to Celcius */
 convertTempFtoC: (fTemp) => {
   let cTemp;
   // your logic goes here
   cTemp = (5/9) * (fTemp - 32); 
   return cTemp;
 }

}
