# javascript-demo-project
Basic JavaScript project for demonstration of programming concepts.

Run `npm install` to get started